# ORCA (SIH26176) — Complete System Guide & Architecture Reference

**Document Name:** `current.md`  
**System Status:** **100% Implemented, Integrated, and Live**  
**Classification:** Technical Architecture, Data Lifecycle, API Contracts & Frontend User Guide  

---

## Table of Contents
1. [Executive Summary & Problem Statement (SIH26176)](#1-executive-summary--problem-statement-sih26176)
2. [Core Architectural Rules & Governance](#2-core-architectural-rules--governance)
3. [System Architecture & 5-Tier Operating Topology](#3-system-architecture--5-tier-operating-topology)
4. [Frontend User Guide (Every View & Component)](#4-frontend-user-guide-every-view--component)
5. [User Inputs: What the User Sends](#5-user-inputs-what-the-user-sends)
6. [Response Generation: Where & How Data Is Created](#6-response-generation-where--how-data-is-created)
7. [User Response Delivery: How the User Gets Data](#7-user-response-delivery-how-the-user-gets-data)
8. [Complete API Directory & JSON Schemas](#8-complete-api-directory--json-schemas)
9. [Database Architecture & MongoDB Collections](#9-database-architecture--mongodb-collections)
10. [AI Multi-Agent Pipeline & Risk Engine](#10-ai-multi-agent-pipeline--risk-engine)
11. [Operations & Maintenance Manual](#11-operations--maintenance-manual)

---

## 1. Executive Summary & Problem Statement (SIH26176)

### 1.1 The Challenge
Operating small and medium vessels in Indian coastal waters poses severe safety challenges. Traditional weather forecasts provide broad regional summaries that fail to capture **localized microclimates**, **coastal bathymetry**, **tidal interactions**, and **vessel-specific vulnerabilities**. A 2.0-meter swell that is harmless to an offshore supply ship can capsize a 28-foot fiberglass fishing canoe. Furthermore, existing systems lack explainability: operators receive binary warnings without knowing *why* an area is dangerous or *where* safe alternative water lies.

### 1.2 The ORCA Solution
**ORCA** is an autonomous, multi-agent AI maritime safety and decision support system designed specifically for Indian coastal waters. It combines:
1. **Multi-Agent Real-Time Data Ingestion**: Five specialized agents fetch live weather, oceanographic swell/waves, cyclone trajectories, tidal constituents, and 22 GIS maritime boundaries.
2. **Deterministic 4-Stage Risk Engine**: Mathematical scoring calibrated to vessel specifications, enforced by official IMD/INCOIS warning floors and hard GIS exclusions, supplemented by bounded Google Gemini LLM reasoning.
3. **9-Point Spatial Matrix ($P0$ to $P8$)**: Evaluates not just the target harbor or fishing spot, but 8 surrounding radial points (cardinal and intercardinal) to identify sheltered lee waters and safer alternatives.
4. **Accessible Maritime Interface**: High-contrast Sunlight Deck Mode, traffic-light visual indicators, voice recognition, and multilingual audio synthesis in 6 Indian languages (English, Hindi, Tamil, Telugu, Malayalam, Bengali).
5. **Zero Fabrication Principle**: ORCA never invents or hallucinates telemetry. If data is unavailable, it is explicitly flagged with source attribution and timestamping.

---

## 2. Core Architectural Rules & Governance

ORCA operates under strict non-negotiable architectural constraints:

```
┌────────────────────────────────────────────────────────────────────────┐
│                         NON-NEGOTIABLE RULES                           │
├────────────────────────────────────────────────────────────────────────┤
│ 1. Frontend talks ONLY to the Backend Gateway (Port 4000 / Proxy 5173). │
│ 2. Frontend RENDERS, NEVER DECIDES risk, safety, or routing.           │
│ 3. Backend is the ONLY component authorized to talk to MongoDB & AI.   │
│ 4. AI Service NEVER writes directly to MongoDB.                        │
│ 5. AI Service delivers results via authenticated JWT callback to :4100.│
│ 6. Risk Scoring is DETERMINISTIC; LLM adjustments are strictly bounded.│
│ 7. ZERO FABRICATION: Missing data is marked "—", never hallucinated.    │
│ 8. Hard GIS Prohibitions ALWAYS override weather scores (Score = 100).  │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 3. System Architecture & 5-Tier Operating Topology

The ORCA system runs across five isolated, cooperative processes:

```mermaid
graph TD
    User["Maritime Operator (Browser / Mobile / Deck Display)"]
    Frontend["Frontend Web Server (Port 5173)<br/>React 19 + Tailwind CSS + Leaflet"]
    PubBackend["Backend Public Gateway (Port 4000)<br/>Express + Ajv Validation + Rate Limiter"]
    IntBackend["Backend Internal Gateway (Port 4100)<br/>Express + JWT HS256 + SSE Broadcaster"]
    AIService["AI Multi-Agent Service (Port 8000)<br/>FastAPI + Python AsyncIO + Gemini LLM"]
    MongoDB[("MongoDB Database (Port 27017)<br/>Analyses, Risk, Decisions, GIS")]

    User <-->|HTTP / WebSocket / SSE| Frontend
    Frontend <-->|Internal Proxy /api/v1| PubBackend
    PubBackend <-->|Mongoose ODM| MongoDB
    PubBackend -->|POST /execute + JWT| AIService
    AIService -->|POST /internal/v1/progress| IntBackend
    AIService -->|POST /internal/v1/result| IntBackend
    IntBackend <-->|Mongoose ODM| MongoDB
    IntBackend -.->|SSE Live Updates| PubBackend
```

### 3.1 Network Services Summary

| Service | Port | Technology | Working Directory | Primary Role |
| :--- | :---: | :--- | :--- | :--- |
| **MongoDB** | `27017` | WiredTiger (0.25GB cache) | `orca/mongo_data` | Persistent storage for analyses, GIS layers, decisions, users, and audit logs. |
| **AI Multi-Agent Service** | `8000` | FastAPI, Python 3.11, AsyncIO | `orca/ai-service` | Autonomous multi-agent pipeline, spatial sampling, 4-stage risk engine, Gemini synthesis. |
| **Backend Internal Gateway** | `4100` | Node.js, Express | `orca/backend` | Private gateway accepting AI progress messages and validated result payloads via JWT. |
| **Backend Public Gateway** | `4000` | Node.js, Express, Ajv | `orca/backend` | Public REST API, input schema validation, rate limiting, and client status polling/SSE. |
| **Frontend Web Application** | `5173` | Node.js (`serve.js`), React 19 | `orca/frontend` | Client UI, Leaflet GIS rendering, Web Speech API audio, and reverse proxy to Port 4000. |

---

## 4. Frontend User Guide (Every View & Component)

The ORCA frontend is built with React 19 and Tailwind CSS. It is fully responsive, optimized for low-bandwidth marine satellite links, and features a specialized **Sunlight Deck Mode** designed for visibility under direct tropical sunlight on open boat decks.

### 4.1 Global Controls & Navigation (`Navbar.jsx`)
- **Brand Logo & Version**: Displays `ORCA SIH26176` and system health status.
- **Navigation Tabs**:
  - `Home`: Natural language entry and rapid scenario chips.
  - `Setup`: Parametric mission configuration and interactive map picker.
  - `Advisory Hub`: Comprehensive decision dashboard and 9-point spatial matrix.
  - `Route`: Coastal A*/Dijkstra passage planner with segment risk coloring.
  - `At-Sea`: High-contrast Geofence deck HUD with audio proximity alerts.
  - `Alerts`: Push/SMS alert subscriptions and broadcast warning inbox.
  - `History`: Searchable archive of all historical analyses in MongoDB.
  - `GIS`: Full-screen 22-layer oceanographic and maritime boundary explorer.
  - `Profile`: Operator preferences, default vessel, and Sunlight Mode toggle.
- **Sunlight Mode Toggle**: Switches UI between deep ocean dark theme and high-contrast sunlight theme (black text on stark white/amber backgrounds).
- **System Status Indicator**: Real-time pulsing green dot verifying live connection to Port 4000.

---

### 4.2 Page 1: Home / Ask ORCA (`HomeAskOrca.jsx`)
- **Natural Language Query Bar**: Allows operators to type or dictate natural queries, e.g.:
  > *"Can I take my 32ft trawler out of Cochin harbor tomorrow morning around 5 AM?"*
- **Speech-to-Text Microphone**: Uses browser Web Speech Recognition to transcribe spoken queries in English, Hindi, Tamil, Telugu, Malayalam, or Bengali.
- **Quick Scenario Chips**: Pre-built one-click queries for instant demonstration:
  - *Cochin Harbor (Trawler - Morning)*
  - *Mangalore Coast (Motorized - Full Day)*
  - *Visakhapatnam (Cargo Coaster - Evening)*
  - *Mumbai High (Offshore Support - Night)*
- **Refine Parameters Drawer**: Collapsible panel allowing quick adjustment of vessel type, search radius (km), and departure date without leaving the home screen.
- **Cached Advisory Resume Banner**: Automatically detects the latest completed analysis from MongoDB and displays an instant resume prompt with relative age (*"Advisory generated 12 min ago"*).

---

### 4.3 Page 2: Mission Setup & Input (`AnalysisInputPage.jsx`)
The complete parametric setup page for structured operational planning:
- **Geographic Location Inputs**:
  - `Latitude` and `Longitude` numerical inputs with validation.
  - `📍 Use My Location` Button: Queries browser Geolocation API and populates coordinates.
  - `🗺️ Click on Map` Modal: Opens an interactive Leaflet map allowing users to pinpoint any location in the Indian Ocean, Arabian Sea, or Bay of Bengal.
- **Temporal Windows**:
  - `Date Picker`: Restricts selection to valid forecast dates (today up to +7 days).
  - `Time Range Slider`: Start time and end time selectors (e.g. `05:00` to `13:00`).
- **Activity Selector**: Dropdown supporting:
  - `Commercial Fishing`
  - `Cargo / Coastal Transit`
  - `Passenger Ferry`
  - `Water Sports / Tourism`
  - `Dredging Operations`
  - `Offshore Rig Support`
- **Vessel Specification Profile**:
  - Vessel Type picker (`Motorized Boat`, `Trawler`, `Speed Boat`, `Cargo Coaster`, `Fiberglass Canoe`, `Yacht`).
  - Auto-fills vessel dimensions: Length (meters), Engine Power (HP), and Draft (meters).
  - Allows manual override of vessel parameters.
- **Advanced Parameters**:
  - Search Radius ($R = 5\text{ km}$ to $50\text{ km}$).
  - Maximum Acceptable Risk Threshold (1–100 slider).
  - Preferred Transit Speed (knots).
  - Advisory Output Language.
- **Action Button**: *"Run Multi-Agent Safety Analysis"*, triggering validation and submission.

---

### 4.4 Page 3: Live Progress Screen (`AnalysisLoadingPage.jsx`)
Renders during asynchronous processing, consuming live SSE updates from the backend:
- **Pulsing Header**: *"ORCA IS ANALYZING MARITIME ENVIRONMENT"*.
- **Progress Bar**: Animates from 0% to 100% across analysis milestones.
- **Multi-Agent Checklist**: Shows individual real-time status cards for each agent:
  - 🧭 **Planner Agent**: Intent classified, coastal snapping complete.
  - 🌤️ **Weather Agent**: Ingesting wind speed, gusts, precipitation, visibility.
  - 🌊 **Ocean Agent**: Ingesting swell height, wave period, sea surface temperature.
  - 🌀 **Cyclone Agent**: Scanning IMD storm bulletins and depression tracks.
  - 🗺️ **GIS Agent**: Checking 22 maritime boundary intersections.
  - ⚖️ **Risk & Decision Engine**: Synthesizing 4-stage deterministic scores.
- **Execution Log Stream**: Terminal-style live feed showing internal milestones.
- **Cancel Button**: Allows aborting the job and returning to the setup screen.

---

### 4.5 Page 4: Advisory Dashboard & Decision Hero (`DecisionResultsPage.jsx`)
The primary operational dashboard displaying complete synthesized analysis results:
- **Decision Hero Banner**:
  - Giant verdict badge:
    - 🟢 **SAFE (GO)**: Risk Score 0–34
    - 🟡 **CAUTION**: Risk Score 35–64
    - 🟠 **UNSAFE**: Risk Score 65–84
    - 🔴 **DANGEROUS (NO-GO)**: Risk Score 85–100
  - Plain-Language Synthesis: Full conversational explanation generated by Gemini LLM.
  - One-Line Takeaway: Ultra-clear operational directive (e.g., *"Delay departure until 09:00 IST to avoid morning ebb tide swell exceeding vessel limits"*).
  - Safest Alternative Window: Highlights temporal windows with lower risk scores.
  - Audio Listen Button: Speaks the complete advisory aloud via Web Speech API in the selected regional language.
- **Interactive 9-Point Spatial Matrix (Leaflet Map)**:
  - Displays origin point $P0$ and surrounding radial points $P1$ through $P8$.
  - Pins are color-coded by their calculated risk score (Green, Yellow, Orange, Red, Gray).
  - Clicking any pin selects that point and updates the dashboard view.
  - Displays distance and compass bearing from origin to each alternative point.
  - Highlights the **Safest Preferred Point** (e.g. $P6$) with a distinct pulsing ring.
- **Quadrant Breakdown Cards**:
  - 🌤️ **Weather Quadrant**: Wind speed, wind gusts, wind direction, rain probability, visibility distance.
  - 🌊 **Ocean Quadrant**: Significant wave height ($H_s$), swell height, wave period, sea surface temperature (SST).
  - 🌀 **Hazard & Cyclone Quadrant**: Active storm warnings, distance to nearest cyclone center, barometric pressure trend.
  - 🗺️ **GIS & Regulatory Quadrant**: Marine protected areas, naval firing ranges, territorial waters boundary, shipping lanes.
- **Dashboard View Tabs**:
  - `Overview`: Quadrant cards and decision summary.
  - `Data Evidence`: Full tabular telemetry across all 9 points with source attribution (Open-Meteo, INCOIS, IMD, Bhuvan) and timestamps.
  - `XAI Reasoning Trace`: Detailed arithmetic breakdown of the 4-stage risk pipeline for each point.
  - `Temporal Trend`: Hourly risk forecast chart showing conditions over the next 24–48 hours.

---

### 4.6 Page 5: Point Detail Sheet (`PointDetailSheet.jsx`)
Slide-over modal providing microscopic inspection of any selected spatial point ($P0$–$P8$):
- Exact latitude/longitude coordinates and distance from trip origin.
- Complete raw telemetry table (wind, swell, current, depth, visibility).
- **The 4-Stage Risk Pipeline Breakdown**:
  1. *Stage 1 Baseline Score*: Raw mathematical risk (e.g. `42/100`).
  2. *Stage 2 Official Warning Floor*: Minimum score forced by IMD/INCOIS warnings (e.g. `85/100`).
  3. *Stage 3 Hard GIS Rules*: Forced score for restricted maritime zones (e.g. `100/100 - PROHIBITED`).
  4. *Stage 4 LLM Synergy Adjustment*: Bounded modifier (-10 to +10) for compound hazards (e.g. `+5` for opposing wind vs. tidal current).
  5. *Final Resolved Score*: Final verified risk score.
- Specific point hazards and operational recommendations.

---

### 4.7 Page 6: Floating "Ask ORCA" Copilot & Drawer (`FloatingChatButton.jsx` & `MaritimeChat.jsx`)
- **Persistent Floating Button**: Anchored in the lower-right corner of every page.
- **Slide-Out Chat Drawer**: Opens without interrupting the current page workflow.
- **Context Preservation**: Automatically passes the active analysis ID, selected point, vessel profile, and risk scores into the chat context.
- **Interactive Multi-Turn Dialogue**: Users can ask follow-up questions:
  - *"Why is point P3 unsafe while P6 is safe?"*
  - *"What if my boat has twin 200HP engines instead of 100HP?"*
  - *"Where is the nearest safe shelter if wind increases by 10 knots?"*
- **Voice Input & Audio Playback**: Full two-way voice communication with multilingual speech recognition and text-to-speech synthesis.

---

### 4.8 Page 7: 22-Layer Oceanographic GIS Explorer (`GisExplorer.jsx`)
Full-screen geospatial exploration tool powered by Leaflet:
- **Layer Toggle Drawer**: Checkbox toggles for 22 individual maritime layers:
  - Indian EEZ (Exclusive Economic Zone) Boundary
  - 12 Nautical Mile Territorial Waters
  - International Maritime Boundary Line (IMBL)
  - Marine National Parks & Sanctuaries (Gulf of Mannar, Sundarbans, Gahirmatha)
  - Coral Reef Protected Zones (Lakshadweep, Andaman & Nicobar)
  - Naval Exercise & Firing Danger Areas
  - Offshore Oil & Gas Fields (Bombay High, Krishna Godavari Basin)
  - Submarine Telecommunication Cables
  - Major & Minor Port Limits
  - Traffic Separation Schemes (TSS) & Shipping Fairways
  - Shallow Shoals & Bathymetric Hazard Contours
  - Active Cyclone Track Forecast Cones
- **Interactive Layer Inspection**: Clicking any polygon or line feature displays its legal authority, restrictions, penalty notices, and contact frequencies.

---

### 4.9 Page 8: Coastal Route Planner (`RoutePlannerPage.jsx`)
Deterministic marine passage planning:
- **Origin & Destination Inputs**: Select departure harbor and target fishing/landing ground.
- **Intermediate Waypoints**: Add waypoints to navigate around coastal headlands or hazards.
- **A* / Dijkstra Cost-Grid Routing**: AI Service calculates the optimal passage that minimizes nautical distance while actively avoiding high-risk weather cells and prohibited GIS zones.
- **Segment-by-Segment Risk Visualization**: Route polyline on Leaflet is broken into legs colored by local risk (Green, Yellow, Orange, Red).
- **Voyage Summary**: Total distance (nautical miles), estimated transit time (hours:minutes), fuel consumption estimate, and leg-by-leg waypoint coordinates.

---

### 4.10 Page 9: At-Sea Geofence Deck Mode (`GeofenceMonitor.jsx`)
Dedicated full-screen HUD designed for active navigation on vessel decks:
- **Ultra-High Contrast Display**: Stark black background with luminous neon status indicators.
- **Three-State Visual Alert Status**:
  - 🟢 **CLEAR**: Vessel is in authorized waters, > 2.0 km from nearest boundary.
  - 🟡 **APPROACHING**: Vessel is within warning buffer (0.5 km – 2.0 km) of a restricted zone or international boundary.
  - 🔴 **INSIDE / CRITICAL**: Vessel has breached a restricted maritime boundary.
- **Live GPS Simulator & Tracking**: Simulates real-time vessel movement or reads browser GPS.
- **Audio Alarm Siren**: Generates sound alarms when breaching warning or prohibited thresholds.
- **Nearest Boundary Metric**: Continuously displays distance in meters and bearing to closest boundary.

---

### 4.11 Page 10: My Advisories History Archive (`HistoryPage.jsx`)
- Displays all historical analyses saved in MongoDB.
- Filterable by date, location name, vessel type, and safety verdict.
- One-click reload: Instantly re-opens any historical advisory in the full Decision Dashboard.
- Export options: Download raw JSON or print official report.

---

### 4.12 Page 11: Alerts & Notification Hub (`AlertsPage.jsx`)
- **Notification Subscriptions**:
  - Contact method: SMS, WhatsApp, Web Push, or Email.
  - Geographical monitoring center and radius (km).
  - Hazard filters: Cyclones, High Waves, Squalls, Coral Zone Breaches.
  - Minimum severity threshold (e.g. only Alert / Danger).
- **Live Broadcast Inbox**:
  - Real-time feed of official bulletins issued by IMD, INCOIS, and Indian Coast Guard.

---

### 4.13 Page 12: Operator Profile & Deck Settings (`ProfileSettingsPage.jsx`)
- Operator name, license ID, and home port harbor.
- Default vessel specifications (saved in `localStorage` and auto-populated in Mission Setup).
- Default language preference for audio speech and written advisories.
- Offline Cache Manager: Displays cached advisory size and permits one-click clearing.

---

### 4.14 Modal 13: Shareable Official Report (`ReportModal.jsx`)
- Generates a formal, printable maritime advisory bulletin.
- Includes official document headers, timestamp, vessel specifications, safety verdict, 9-point grid table, and authorized sign-off block.
- Single-click print styling optimized for physical paper printing or PDF export for port clearance authorities.

---

## 5. User Inputs: What the User Sends

ORCA accepts two forms of user input: **Natural Language Queries** and **Parametric Mission Specifications**.

### 5.1 Input Schema Reference Table

| Field Name | Type | Required | Range / Enum | Example Value | Description |
| :--- | :--- | :---: | :--- | :--- | :--- |
| `query` | String | Yes | 1 – 500 chars | `"Can I fish near Mangalore?"` | Operator's operational query. |
| `coordinates.latitude` | Float | Yes | $-90.0$ to $+90.0$ | `12.87` | Target destination latitude. |
| `coordinates.longitude` | Float | Yes | $-180.0$ to $+180.0$ | `74.84` | Target destination longitude. |
| `date` | String | Yes | ISO `YYYY-MM-DD` | `"2026-09-15"` | Target operation date. |
| `time_range.start` | String | Yes | `HH:MM` (24h) | `"05:00"` | Operation commencement time. |
| `time_range.end` | String | Yes | `HH:MM` (24h) | `"13:00"` | Operation completion time. |
| `activity` | String | Yes | `fishing`, `cargo`, `passenger`, `sports`, `dredging`, `offshore_support` | `"fishing"` | Operational mission type. |
| `vessel.type` | String | Yes | `motorized_boat`, `trawler`, `speed_boat`, `cargo_coaster`, `canoe_fiberglass`, `yacht` | `"trawler"` | Vessel hull classification. |
| `vessel.length_meters`| Float | Yes | $1.0$ to $300.0$ | `14.5` | Overall length in meters. |
| `vessel.engine_power_hp`| Float | Yes | $5.0$ to $50000.0$ | `120.0` | Engine shaft horsepower. |
| `vessel.draft_meters` | Float | Yes | $0.2$ to $25.0$ | `1.8` | Vessel draft below waterline. |
| `parameters.radius_km`| Float | No | $5.0$ to $50.0$ (def: 15) | `15.0` | Spatial sampling grid radius. |
| `parameters.max_acceptable_risk` | Integer | No | $1$ to $100$ (def: 65) | `60` | Operator risk tolerance ceiling. |
| `parameters.preferred_speed_knots`| Float | No | $1.0$ to $50.0$ | `8.5` | Cruising transit speed. |
| `parameters.language` | String | No | `en`, `hi`, `ta`, `te`, `ml`, `bn` | `"en"` | Language for output synthesis. |

---

### 5.2 Exact JSON Request Payload Sent by Frontend

When the user clicks *"Run Multi-Agent Safety Analysis"*, the frontend validates all fields and sends an HTTP POST request to the Public Backend Gateway:

```http
POST /api/v1/analysis HTTP/1.1
Host: localhost:4000
Content-Type: application/json
Accept: application/json

{
  "query": "Can I operate a 14.5m trawler out of Mangalore harbor tomorrow morning?",
  "coordinates": {
    "latitude": 12.87,
    "longitude": 74.84
  },
  "date": "2026-09-15",
  "time_range": {
    "start": "05:00",
    "end": "13:00"
  },
  "activity": "fishing",
  "vessel": {
    "type": "trawler",
    "length_meters": 14.5,
    "engine_power_hp": 120.0,
    "draft_meters": 1.8
  },
  "parameters": {
    "radius_km": 15.0,
    "max_acceptable_risk": 60,
    "preferred_speed_knots": 8.5,
    "language": "en"
  }
}
```

---

## 6. Response Generation: Where & How Data Is Created

The complete lifecycle from user click to final advisory consists of **10 sequential stages** spanning all five system services:

```mermaid
sequenceDiagram
    autonumber
    actor User as Operator (Browser)
    participant Front as Frontend (5173)
    participant Pub as Backend Public (4000)
    participant DB as MongoDB (27017)
    participant AI as AI Service (8000)
    participant Int as Backend Internal (4100)

    User->>Front: Clicks "Run Analysis"
    Front->>Pub: POST /api/v1/analysis (AnalysisRequest)
    Pub->>Pub: Ajv Validate (AnalysisRequest.json)
    Pub->>DB: Insert AnalysisDoc (status="queued", analysis_id)
    Pub-->>Front: HTTP 202 Accepted { analysis_id, status_url }
    Front->>Front: Navigate to /loading screen (SSE subscribe)

    Pub->>AI: POST /execute (with HS256 JWT)
    AI-->>Pub: HTTP 202 Accepted (Background task started)
    
    rect rgb(240, 248, 255)
    note right of AI: AI Multi-Agent Pipeline Executes
    AI->>AI: Planner: Gemini NLP + Offshore Snapping + 9-Point Grid (P0..P8)
    AI->>Int: POST /internal/v1/progress (Planner Done)
    Int->>Pub: SSE Broadcast (Stage: Planner)
    Pub-->>Front: SSE Event (Update Progress Bar)

    par Concurrent Agent Data Ingestion
        AI->>AI: Weather Agent: Wind, Gusts, Rain, Visibility
        AI->>AI: Ocean Agent: Swell, Wave Height, Period, SST
        AI->>AI: Cyclone Agent: Storm Bulletins, Track Cones
        AI->>AI: GIS Agent: 22 Maritime Boundary Intersections
        AI->>AI: Tide Agent: Harmonic Constituents, Slack Water
    end

    AI->>Int: POST /internal/v1/progress (Agents Done)
    Int->>Pub: SSE Broadcast (Stage: Data Ingestion)
    Pub-->>Front: SSE Event (Update Agent Checklist)

    AI->>AI: 4-Stage Risk Pipeline per Point (P0..P8)
    AI->>AI: Decision Synthesis: Ranks P0..P8, picks best P6, Gemini writes advisory
    end

    AI->>Int: POST /internal/v1/result (InternalResultPayload + JWT)
    Int->>Int: Ajv Validate (InternalResultPayload.json)
    Int->>DB: Update AnalysisDoc (status="completed", decision, points, risk)
    Int->>Pub: SSE Broadcast (Status: Completed)
    Pub-->>Front: SSE Event (Completed)

    Front->>Pub: GET /api/v1/analysis/:id
    Pub->>DB: Query AnalysisDoc
    DB-->>Pub: Return Analysis Document
    Pub-->>Front: HTTP 200 OK (Full Advisory Payload)
    Front->>Front: Render Decision Dashboard, Leaflet 9-Point Map, Quadrants
    Front-->>User: Visual Verdict & Regional Audio TTS Speaks Advisory
```

### 6.1 Step-by-Step Execution Breakdown

#### Step 1: Frontend Ingestion & Pre-Validation
- User fills the mission form or speaks into the microphone.
- Form inputs are validated in React for required fields and numerical ranges.
- A unique submission timestamp is recorded.

#### Step 2: Backend Public Gateway Processing (`Port 4000`)
- Express server receives the request on `POST /api/v1/analysis`.
- **Ajv (Another JSON Schema Validator)** validates the body against `contracts/AnalysisRequest.json` with `additionalProperties: false`. If invalid, an immediate HTTP 400 with field errors is returned.
- Generates a cryptographically secure UUID `analysis_id` (e.g. `anl_7f8a9b2c3d4e`).
- Creates a new document in the MongoDB `analyses` collection with `status: "queued"`.
- Responds immediately to the client with `HTTP 202 Accepted` containing `{ analysis_id, status_url: "/api/v1/analysis/:id/status" }`.

#### Step 3: AI Service Dispatch (`Port 8000`)
- Backend constructs `InternalExecutionRequest.json`.
- Signs an HS256 JWT using `INTERNAL_JWT_SECRET` containing `{ iss: "orca-backend", sub: analysis_id }`.
- Calls AI Service endpoint `POST http://localhost:8000/execute` with bearer token.
- AI Service validates the JWT, registers the task in its AsyncIO event loop, and returns `HTTP 202 Accepted`.

#### Step 4: AI Planner Stage
- **Language Detection & Intent**: Gemini LLM parses the input query. Detects query intent (e.g. `point_safety`, `route_planning`, or `temporal_window`).
- **Offshore Snapping**: If the user selected coordinates on land or inside a closed harbor basin, the spatial engine calculates the nearest open ocean coordinate and snaps the target 2.0 km seaward.
- **9-Point Spatial Grid Generation**:
  - Center Point ($P0$): Target offshore coordinate.
  - Radial Points ($P1$ to $P8$): 8 points generated at radius $R$ ($15\text{ km}$) distributed along compass azimuths ($0^\circ, 45^\circ, 90^\circ, 135^\circ, 180^\circ, 225^\circ, 270^\circ, 315^\circ$):
    - $P1$: North
    - $P2$: North-East
    - $P3$: East
    - $P4$: South-East
    - $P5$: South
    - $P6$: South-West
    - $P7$: West
    - $P8$: North-West
- **Time Window Standardization**: Resolves local Indian Standard Time (IST, UTC+5:30) and standardized UTC intervals.

#### Step 5: Parallel Multi-Agent Data Ingestion
Five autonomous agents execute concurrently across all 9 spatial points via Python's `asyncio.gather()`:
1. **Weather Agent**: Fetches wind speed (m/s & knots), gust speed, wind direction (degrees), precipitation rate (mm/hr), and visibility (km) via Open-Meteo marine models and IMD bulletins.
2. **Ocean Agent**: Fetches significant wave height ($H_s$, meters), swell wave height, swell period (seconds), swell direction, sea surface temperature (SST, $^\circ\text{C}$), and ocean surface current velocity (knots) via INCOIS and Copernicus marine models.
3. **Cyclone Agent**: Scans active IMD/RSMC storm advisories. Computes distance to nearest depression center, central pressure deficit (hPa), and active track cone intersection.
4. **GIS Agent**: Performs point-in-polygon and distance-to-geometry queries using Shapely and GeoPandas across 22 maritime vector shapefiles. Identifies overlaps with Marine Protected Areas, naval firing zones, shipping lanes, and EEZ boundaries.
5. **Tide Agent**: Computes astronomical tidal constituents for the nearest Indian port tidal station, predicting high tide, low tide, tidal range, and slack water windows.

#### Step 6: The 4-Stage Deterministic Risk Engine
For every point $P0$ through $P8$, the risk engine calculates an exact mathematical risk score from 0 (completely safe) to 100 (lethal danger):

```
┌────────────────────────────────────────────────────────────────────────┐
│                     THE 4-STAGE RISK PIPELINE                          │
├────────────────────────────────────────────────────────────────────────┤
│ STAGE 1: Deterministic Baseline Scoring (0 - 100)                      │
│   - Calculated strictly from vessel tolerances vs. physical data.      │
│   - Wind component + Swell component + Visibility component.          │
│                                                                        │
│ STAGE 2: Official Warning Safety Floors                                │
│   - If IMD Red Alert active:             Risk Score = MAX(Score, 85)   │
│   - If INCOIS High Wave Warning active:  Risk Score = MAX(Score, 75)   │
│   - If IMD Yellow Alert active:          Risk Score = MAX(Score, 50)   │
│                                                                        │
│ STAGE 3: Hard GIS Rules Enforcement                                    │
│   - If Point intersects Prohibited Military/Naval Zone: Score = 100    │
│   - If Point intersects Marine Sanctuary Core:          Score = 100    │
│   - Prohibited points are permanently marked "EXCLUDED".               │
│                                                                        │
│ STAGE 4: Bounded LLM Reasoning Adjustment (-10 to +10)                 │
│   - Google Gemini 1.5 Flash evaluates non-linear compound synergies:   │
│     * Wind blowing directly against ebbing tide (steepens waves).      │
│     * Rapidly dropping barometric pressure with rising swell.          │
│   - Adjustment is strictly bounded between -10 and +10.                │
│                                                                        │
│ FINAL RESOLVED SCORE = CLAMP(Stage3_Enforced_Score + LLM_Adj, 0, 100)  │
└────────────────────────────────────────────────────────────────────────┘
```

#### Step 7: Decision Synthesis & Natural Language Advisory
- **Point Selector**: Evaluates all 9 points. Discards points with Score $\ge 85$ or GIS exclusions.
- **Safest Point Identification**: Ranks valid points. If origin $P0$ is CAUTION (e.g. 52) but southwest point $P6$ is sheltered by headland bathymetry with Score 24, $P6$ is designated as the **Preferred Safe Point**.
- **Temporal Alternative Finder**: Scans forecast intervals over the next 24 hours to find optimal operational windows (e.g. *"Conditions improve significantly after 10:30 AM"*).
- **Gemini LLM Advisory Formulation**: Generates:
  - `synthesis`: Plain-language explanation covering wind, swell, and tide factors.
  - `one_line_summary`: Immediate operational directive.
  - `reasoning_trace`: Step-by-step explainability trail.
  - `key_warnings`: Bulleted priority hazards.

#### Step 8: Internal Callback & Result Ingestion (`Port 4100`)
- AI Service compiles `InternalResultPayload.json` containing the execution plan, all 9 point observations, 4-stage risk breakdown, and final decision.
- Signs an HS256 JWT and sends `POST http://localhost:4100/internal/v1/result`.
- Internal Gateway validates the payload with Ajv against `contracts/InternalResultPayload.json`.
- Mongoose updates the MongoDB `analyses` document: sets `status: "completed"`, stores the full decision, and writes audit records to `risk_results` and `agent_results`.
- Emits an SSE event notifying connected clients that processing is finished.

#### Step 9: Client Extraction
- The frontend loading page detects the completion event (via SSE or polling `/api/v1/analysis/:id/status`).
- Triggers an HTTP `GET /api/v1/analysis/:id` to retrieve the complete consolidated analysis document.

#### Step 10: Frontend Visualization & Audio Synthesis
- Navigates to the Advisory Dashboard (`DecisionResultsPage.jsx`).
- Renders the giant Decision Hero banner with the calculated color verdict.
- Leaflet map initializes and draws the 9-point radial pins with interactive click handlers.
- Quadrant cards display structured weather, ocean, hazard, and GIS metrics.
- Web Speech API synthesizes the advisory aloud in the user's selected Indian language.

---

## 7. User Response Delivery: How the User Gets Data

The user receives data through three synchronized channels:
1. **Immediate HTTP Acknowledgement**: Initial 202 response with analysis ID.
2. **Real-Time Streaming Updates**: Server-Sent Events (SSE) or polling stream showing progress across each agent.
3. **Consolidated Advisory Payload**: Complete structured JSON document rendered into visual dashboards, map layers, and synthesized speech.

---

## 8. Complete API Directory & JSON Schemas

### 8.1 Backend Public Gateway Endpoints (`Port 4000`)

#### 1. System Health Check
- **Method / URL**: `GET /health`
- **Purpose**: Uptime and service health verification.
- **Response (`200 OK`)**:
```json
{
  "status": "ok",
  "service": "orca-backend",
  "env": "development",
  "uptime_seconds": 3412,
  "timestamp": "2026-09-15T12:00:00.000Z"
}
```

#### 2. Submit Maritime Analysis Request
- **Method / URL**: `POST /api/v1/analysis`
- **Purpose**: Submits a new mission safety request.
- **Request Body**: Validated against `AnalysisRequest.json` (see [Section 5.2](#52-exact-json-request-payload-sent-by-frontend)).
- **Response (`202 Accepted`)**:
```json
{
  "status": "queued",
  "analysis_id": "anl_9a8b7c6d5e4f",
  "status_url": "/api/v1/analysis/anl_9a8b7c6d5e4f/status",
  "created_at": "2026-09-15T12:00:01.120Z",
  "estimated_completion_seconds": 8
}
```

#### 3. Poll Analysis Progress
- **Method / URL**: `GET /api/v1/analysis/:id/status`
- **Purpose**: Lightweight status polling for client progress tracking.
- **Response (`200 OK` - In Progress)**:
```json
{
  "analysis_id": "anl_9a8b7c6d5e4f",
  "status": "running",
  "stage": "agent_data_collection",
  "progress_pct": 65,
  "completed_agents": ["planner", "weather", "ocean", "cyclone"],
  "pending_agents": ["gis", "tide"],
  "updated_at": "2026-09-15T12:00:04.500Z"
}
```
- **Response (`200 OK` - Completed)**:
```json
{
  "analysis_id": "anl_9a8b7c6d5e4f",
  "status": "completed",
  "stage": "completed",
  "progress_pct": 100,
  "result_url": "/api/v1/analysis/anl_9a8b7c6d5e4f",
  "completed_at": "2026-09-15T12:00:07.850Z"
}
```

#### 4. Real-Time SSE Stream
- **Method / URL**: `GET /api/v1/analysis/:id/stream`
- **Protocol**: Server-Sent Events (`text/event-stream`).
- **Event Stream Output**:
```
event: progress
data: {"analysis_id":"anl_9a8b7c6d5e4f","stage":"planner","progress_pct":20}

event: progress
data: {"analysis_id":"anl_9a8b7c6d5e4f","stage":"weather_agent","progress_pct":40}

event: progress
data: {"analysis_id":"anl_9a8b7c6d5e4f","stage":"risk_engine","progress_pct":80}

event: completed
data: {"analysis_id":"anl_9a8b7c6d5e4f","status":"completed","result_url":"/api/v1/analysis/anl_9a8b7c6d5e4f"}
```

#### 5. Fetch Full Consolidated Analysis Advisory
- **Method / URL**: `GET /api/v1/analysis/:id`
- **Purpose**: Retrieves the full decision, 9-point spatial matrix, telemetry, and XAI trace.
- **Response (`200 OK`)**:
```json
{
  "analysis_id": "anl_9a8b7c6d5e4f",
  "status": "completed",
  "created_at": "2026-09-15T12:00:01.120Z",
  "completed_at": "2026-09-15T12:00:07.850Z",
  "request": {
    "query": "Can I operate a 14.5m trawler out of Mangalore harbor tomorrow morning?",
    "coordinates": { "latitude": 12.87, "longitude": 74.84 },
    "date": "2026-09-15",
    "time_range": { "start": "05:00", "end": "13:00" },
    "activity": "fishing",
    "vessel": {
      "type": "trawler",
      "length_meters": 14.5,
      "engine_power_hp": 120.0,
      "draft_meters": 1.8
    }
  },
  "decision": {
    "verdict": "CAUTION",
    "overall_risk_score": 48,
    "confidence_score": 0.94,
    "one_line_summary": "Operate with caution near harbor mouth; conditions stabilize 5 km southwest.",
    "synthesis": "Morning conditions exhibit moderate southwesterly swell of 1.6m with wind gusts reaching 19 knots during the outgoing tide (06:00 to 08:30 IST). Small craft and fiberglass canoes are advised against venturing beyond 5 NM. Your 14.5m trawler can operate safely by departing after 08:30 IST toward spatial sector P6.",
    "preferred_point_id": "P6",
    "excluded_points": ["P3"],
    "best_time_windows": [
      { "start": "08:30", "end": "13:00", "expected_risk_score": 26, "reason": "Slack water after ebb tide reduces wave steepness" }
    ],
    "key_warnings": [
      "Harbor mouth tidal rip between 06:00 and 08:00 IST",
      "P3 enters naval practice boundary sector B (prohibited)"
    ],
    "source_attribution": [
      { "source": "Open-Meteo", "model": "ECMWF IFS 0.25", "timestamp": "2026-09-15T11:00:00Z" },
      { "source": "INCOIS", "product": "Ocean State Forecast (OSF)", "timestamp": "2026-09-15T06:00:00Z" },
      { "source": "IMD", "product": "Coastal Weather Bulletin", "timestamp": "2026-09-15T09:30:00Z" }
    ]
  },
  "spatial_matrix": [
    {
      "point_id": "P0",
      "label": "Origin",
      "coordinates": { "latitude": 12.87, "longitude": 74.84 },
      "bearing_deg": 0,
      "distance_km": 0,
      "risk_score": 48,
      "verdict": "CAUTION",
      "telemetry": {
        "wind_speed_knots": 14.2,
        "wind_gusts_knots": 19.1,
        "wind_direction_deg": 230,
        "significant_wave_height_m": 1.6,
        "swell_height_m": 1.4,
        "swell_period_sec": 8.5,
        "sea_surface_temp_c": 28.4,
        "visibility_km": 10.0,
        "precipitation_rate_mm_hr": 0.0
      },
      "risk_stages": {
        "stage_1_baseline": 42,
        "stage_2_warning_floor": 0,
        "stage_3_gis_enforced": 42,
        "stage_4_llm_adjustment": 6,
        "final_score": 48
      }
    },
    {
      "point_id": "P6",
      "label": "South-West (Safest)",
      "coordinates": { "latitude": 12.77, "longitude": 74.73 },
      "bearing_deg": 225,
      "distance_km": 15.0,
      "risk_score": 24,
      "verdict": "SAFE",
      "telemetry": {
        "wind_speed_knots": 10.5,
        "wind_gusts_knots": 13.0,
        "wind_direction_deg": 215,
        "significant_wave_height_m": 0.9,
        "swell_height_m": 0.8,
        "swell_period_sec": 7.0,
        "sea_surface_temp_c": 28.6,
        "visibility_km": 10.0,
        "precipitation_rate_mm_hr": 0.0
      },
      "risk_stages": {
        "stage_1_baseline": 26,
        "stage_2_warning_floor": 0,
        "stage_3_gis_enforced": 26,
        "stage_4_llm_adjustment": -2,
        "final_score": 24
      }
    }
  ]
}
```

#### 6. Fetch Latest Completed Analysis
- **Method / URL**: `GET /api/v1/analysis/latest`
- **Purpose**: Instant dashboard population on page refresh without needing a re-run.
- **Response**: Same payload structure as Endpoint 5.

#### 7. Fetch Analysis History Archive
- **Method / URL**: `GET /api/v1/analysis/history?page=1&limit=20`
- **Purpose**: Paginated list of past maritime evaluations for the logged-in operator.

#### 8. Conversational Copilot Message
- **Method / URL**: `POST /api/v1/chat/message`
- **Request Body**:
```json
{
  "conversation_id": "conv_4a5b6c7d",
  "analysis_id": "anl_9a8b7c6d5e4f",
  "message": "What if I depart at 10 AM instead?",
  "language": "en"
}
```
- **Response (`200 OK`)**:
```json
{
  "conversation_id": "conv_4a5b6c7d",
  "reply": "Departing at 10:00 AM drops your risk score from 48 (CAUTION) down to 22 (SAFE). The ebb tidal current will have subsided, eliminating the steep standing waves at the harbor entrance.",
  "suggested_actions": ["Update Departure Time to 10:00 AM", "View Point P6 Route"],
  "timestamp": "2026-09-15T12:02:15.000Z"
}
```

#### 9. Coastal Passage Route Planning
- **Method / URL**: `POST /api/v1/route`
- **Request Body**:
```json
{
  "origin": { "latitude": 12.87, "longitude": 74.84 },
  "destination": { "latitude": 13.35, "longitude": 74.70 },
  "vessel": {
    "type": "trawler",
    "draft_meters": 1.8,
    "cruising_speed_knots": 8.5
  },
  "departure_time": "2026-09-15T05:00:00Z"
}
```
- **Response (`200 OK`)**:
```json
{
  "route_id": "rt_3e2d1c0b",
  "total_distance_nm": 32.4,
  "estimated_duration_hours": 3.8,
  "average_risk_score": 31,
  "segments": [
    {
      "leg_index": 1,
      "start": { "latitude": 12.87, "longitude": 74.84 },
      "end": { "latitude": 13.05, "longitude": 74.78 },
      "distance_nm": 11.2,
      "risk_score": 45,
      "verdict": "CAUTION"
    },
    {
      "leg_index": 2,
      "start": { "latitude": 13.05, "longitude": 74.78 },
      "end": { "latitude": 13.35, "longitude": 74.70 },
      "distance_nm": 21.2,
      "risk_score": 22,
      "verdict": "SAFE"
    }
  ],
  "waypoints": [
    [12.87, 74.84],
    [13.05, 74.78],
    [13.35, 74.70]
  ]
}
```

#### 10. Real-Time Geofence Boundary Check
- **Method / URL**: `POST /api/v1/geofence/check`
- **Purpose**: Sub-second pure-geometry check for deck HUD.
- **Request Body**:
```json
{
  "coordinates": { "latitude": 12.85, "longitude": 74.80 },
  "vessel_id": "IND-KA-02-MM-1244",
  "speed_knots": 7.8,
  "heading_deg": 240
}
```
- **Response (`200 OK`)**:
```json
{
  "status": "CLEAR",
  "nearest_restricted_layer": "Naval Exercise Sector B",
  "distance_to_boundary_km": 4.82,
  "bearing_to_boundary_deg": 265,
  "time_to_boundary_minutes": 20.1,
  "action_required": "Maintain current heading"
}
```

---

### 8.2 Backend Internal Gateway Endpoints (`Port 4100`)

#### 1. Internal Progress Callback
- **Method / URL**: `POST /internal/v1/progress`
- **Auth**: Bearer JWT (HS256) signed by AI Service.
- **Payload (`ProgressMessage.json`)**:
```json
{
  "analysis_id": "anl_9a8b7c6d5e4f",
  "status": "running",
  "stage": "agent_ocean",
  "progress_pct": 50,
  "message": "Ocean wave and swell telemetry ingested across 9 points"
}
```

#### 2. Internal Result Ingestion Callback
- **Method / URL**: `POST /internal/v1/result`
- **Auth**: Bearer JWT (HS256) signed by AI Service.
- **Payload**: Full `InternalResultPayload.json` containing complete point observations, risk stage calculations, and decision synthesis.

---

### 8.3 AI Multi-Agent Service Endpoints (`Port 8000`)

#### 1. Service Health Check
- **Method / URL**: `GET /health`
- **Response (`200 OK`)**:
```json
{
  "status": "ok",
  "service": "orca-ai-service",
  "gemini_model": "gemini-1.5-flash",
  "active_agents": ["weather", "ocean", "cyclone", "gis", "tide", "planner", "decision"]
}
```

#### 2. Trigger Autonomous Execution
- **Method / URL**: `POST /execute`
- **Auth**: Bearer JWT (HS256) signed by Backend Public Gateway.
- **Payload**: `InternalExecutionRequest.json`.
- **Response**: `202 Accepted` (triggers background AsyncIO pipeline).

---

## 9. Database Architecture & MongoDB Collections

MongoDB runs on `localhost:27017` with WiredTiger cache capped at 0.25GB. The ORCA database schema comprises 10 collections:

```
orca database
├── analyses                 # Master mission record with lifecycle status
├── risk_results             # 4-stage risk breakdown per spatial point
├── decisions                # Synthesized operational recommendations
├── agent_results            # Raw telemetry per agent per point
├── gis_layers               # 22 GeoJSON maritime boundary layers
├── alert_subscriptions      # Push/SMS notification targets
├── alert_events             # Audit log of dispatched alert notifications
├── geofence_events          # Audit log of vessel geofence breaches
├── conversations            # Chat copilot dialogue history
├── routes                   # Calculated coastal passage plans
└── reports                  # Formatted printable bulletin archives
```

### 9.1 Collection Details & Indexes

| Collection Name | Document Schema | Primary Index | Compound / Geospatial Indexes |
| :--- | :--- | :--- | :--- |
| `analyses` | `AnalysesDocument.json` | `_id` | `{ analysis_id: 1 }` (unique), `{ "request.coordinates": "2dsphere" }`, `{ status: 1, created_at: -1 }` |
| `risk_results` | `RiskResultsDocument.json` | `_id` | `{ analysis_id: 1, point_id: 1 }` (unique) |
| `decisions` | `Decision.json` | `_id` | `{ analysis_id: 1 }` (unique) |
| `agent_results` | `AgentResult.json` | `_id` | `{ analysis_id: 1, agent_name: 1, point_id: 1 }` |
| `gis_layers` | `GisLayerDocument.json` | `_id` | `{ layer_name: 1 }`, `{ geometry: "2dsphere" }` |
| `geofence_events` | `GeofenceEventDocument.json`| `_id` | `{ vessel_id: 1, timestamp: -1 }`, `{ coordinates: "2dsphere" }` |
| `conversations` | `ConversationDocument.json`| `_id` | `{ conversation_id: 1 }` (unique), `{ analysis_id: 1 }` |
| `routes` | `RouteResult.json` | `_id` | `{ route_id: 1 }` (unique) |

---

## 10. AI Multi-Agent Pipeline & Risk Engine

### 10.1 Agent Architecture & Responsibilities

```
┌────────────────────────────────────────────────────────────────────────┐
│                     ORCA MULTI-AGENT PIPELINE                          │
├────────────────────────────────────────────────────────────────────────┤
│ 1. PLANNER AGENT                                                       │
│    - Intent classification & multi-lingual query parsing via Gemini.   │
│    - Land-sea masking & offshore coastal snapping.                     │
│    - 9-Point spatial radial matrix generation (P0..P8).                │
│    - Temporal window normalization (IST / UTC).                        │
│                                                                        │
│ 2. WEATHER AGENT                                                       │
│    - Open-Meteo & IMD coastal weather models.                          │
│    - Ingests wind speed, wind gusts, wind direction, rain, visibility. │
│                                                                        │
│ 3. OCEAN AGENT                                                         │
│    - INCOIS OSF & Copernicus marine models.                            │
│    - Ingests significant wave height (Hs), swell height, period, SST.  │
│                                                                        │
│ 4. CYCLONE AGENT                                                       │
│    - RSMC / IMD storm bulletin parser.                                 │
│    - Evaluates depression centers, track forecast cones, storm surge.  │
│                                                                        │
│ 5. GIS AGENT                                                           │
│    - 22 Maritime boundary vector shapefiles (GeoPandas / Shapely).     │
│    - Evaluates EEZ, territorial waters, marine national parks, TSS.    │
│                                                                        │
│ 6. TIDE AGENT                                                          │
│    - Indian port harmonic tidal constituents.                          │
│    - Identifies ebb, flood, high/low astronomical tides, slack water.  │
│                                                                        │
│ 7. DECISION & SYNTHESIS AGENT                                          │
│    - Ranks points, selects optimal safe alternative (P6).              │
│    - Gemini LLM synthesizes operational plain-language bulletin.       │
│    - Constructs XAI explainable reasoning trace.                       │
└────────────────────────────────────────────────────────────────────────┘
```

### 10.2 Mathematical Scoring Formulations (Stage 1 Baseline)

The baseline risk score for a vessel at any point $P_i$ is computed deterministically:

$$\text{Risk}_{\text{baseline}} = w_1 \cdot f_{\text{wind}}(V_{\text{wind}}, V_{\text{gust}}) + w_2 \cdot f_{\text{wave}}(H_s, T_{\text{swell}}) + w_3 \cdot f_{\text{vis}}(\text{Vis}) + w_4 \cdot f_{\text{tide}}(\text{TideState})$$

Where weights satisfy $\sum w_i = 1.0$, calibrated by vessel length $L$ and draft $D$:
- For small craft ($L < 10\text{ m}$), wave height weight $w_2 = 0.50$, wind weight $w_1 = 0.35$.
- For coastal cargo ($L > 50\text{ m}$), wave weight $w_2 = 0.25$, wind weight $w_1 = 0.25$, bathymetry/draft weight increases to $0.40$.

---

## 11. Operations & Maintenance Manual

### 11.1 How to Start All Five Servers

Open PowerShell in the workspace root directory:

```powershell
# 1. Start MongoDB (Port 27017) with memory cache cap
& "C:\Program Files\MongoDB\Server\8.3\bin\mongod.exe" `
    --dbpath "c:\Users\arpit\Desktop\main orca\orca new - Copy antg\orca\mongo_data" `
    --port 27017 `
    --bind_ip 127.0.0.1,::1 `
    --wiredTigerCacheSizeGB 0.25 `
    --logpath "c:\Users\arpit\Desktop\main orca\orca new - Copy antg\orca\mongod.log"

# 2. Start AI Multi-Agent Service (Port 8000)
cd "c:\Users\arpit\Desktop\main orca\orca new - Copy antg\orca\ai-service"
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000

# 3. Start Backend Internal Gateway (Port 4100)
cd "c:\Users\arpit\Desktop\main orca\orca new - Copy antg\orca\backend"
npm run internal

# 4. Start Backend Public Gateway (Port 4000)
cd "c:\Users\arpit\Desktop\main orca\orca new - Copy antg\orca\backend"
node src/server.js

# 5. Start Frontend Web Server & Reverse Proxy (Port 5173)
cd "c:\Users\arpit\Desktop\main orca\orca new - Copy antg\orca\frontend"
node serve.js
```

### 11.2 Production Verification Script

Verify all 5 services with a single PowerShell command:

```powershell
python -c "
import urllib.request
endpoints = [
    ('AI Service', 'http://localhost:8000/health'),
    ('Internal Gateway', 'http://localhost:4100/health'),
    ('Public Gateway', 'http://localhost:4000/health'),
    ('Frontend Proxy', 'http://localhost:5173/health'),
    ('Frontend UI', 'http://localhost:5173/'),
    ('Analysis API', 'http://localhost:5173/api/v1/analysis/latest')
]
for name, url in endpoints:
    try:
        res = urllib.request.urlopen(url, timeout=5)
        print(f'[ONLINE 200 OK] {name:18} -> {url}')
    except Exception as e:
        print(f'[OFFLINE]       {name:18} -> {e}')
"
```

### 11.3 Troubleshooting Common Scenarios

| Symptom | Probable Cause | Corrective Action |
| :--- | :--- | :--- |
| `EADDRINUSE: port 4000/4100` | Stale Node process holding port. | Run `Get-NetTCPConnection -LocalPort 4000` and kill the PID with `Stop-Process -Id <PID> -Force`. |
| `OutOfMemoryError: oxc_allocator` | Direct Vite/Rolldown build was executed. | **NEVER** run `vite build`. Use the verified `esbuild` command: `& "<path-to-esbuild>" src/main.jsx --bundle --outfile=dist/assets/index.js --format=esm --jsx=automatic`. |
| `MongoServerSelectionError` | MongoDB daemon stopped or locked. | Verify `mongod.exe` is running with `--wiredTigerCacheSizeGB 0.25`. Check `mongod.log`. |
| `ContractValidationError: additionalProperties` | Frontend sent unmodeled fields. | Review `contracts/AnalysisRequest.json`. Ensure `date` is `YYYY-MM-DD` and `time_range` is `{ start, end }`. |
| `Backend proxy error 502 on Port 5173` | Backend on Port 4000 is offline. | Start `node src/server.js` in `orca/backend`. |
| `ENOTFOUND orca-ai-service` | Render private networking hostname mismatch. | Set `AI_SERVICE_URL=https://orca-ai-service-b0fx.onrender.com` in `orca-backend` environment. |
| `Offline badge in Navbar` | Frontend API URL pointing to localhost in cloud. | Click the status badge in Navbar and enter `https://orca-backend-anp5.onrender.com/api/v1` or set `VITE_API_BASE_URL`. |

---

## 12. Live Cloud Deployment (Render + MongoDB Atlas)

### 12.1 Production Topology & Service URLs

| Service Name | Render Type | Live Public URL | Underlying Runtime | Responsibility |
| :--- | :--- | :--- | :--- | :--- |
| **`orca-frontend`** | Static Site | `https://orca-frontend-27li.onrender.com` | React 19 + Vite (Global Edge CDN) | Maritime UI, deck mode, interactive Leaflet GIS, AI copilot |
| **`orca-backend`** | Web Service | `https://orca-backend-anp5.onrender.com` | Node.js 20+ Express | Public API gateway, JWT auth, MongoDB Atlas driver, internal routing |
| **`orca-ai-service`** | Web Service | `https://orca-ai-service-b0fx.onrender.com` | Python 3.11.9 FastAPI | Multi-agent telemetry, 9-point risk engine, Gemini synthesis |
| **MongoDB Atlas** | DBaaS Cluster | `Cluster0 (AWS ap-south-1 Mumbai)` | MongoDB 7.0+ Replica Set | 299 GIS maritime boundaries/ports, 230 PFZ line advisories, alerts |

### 12.2 Multi-Activity Platform Scope
ORCA operates as a **General Ocean Risk and Coastal Advisory System** serving all marine stakeholders with neutral defaults:
- `tourism`: Coastal sightseeing, beach excursions, shallow leisure craft.
- `boating`: Recreational sailing, motorboats, marina navigation.
- `diving`: SCUBA diving, reef exploration, sub-surface visibility & current thresholds.
- `surfing`: Nearshore break, swell period, wave steepness, wind direction.
- `shipping`: Commercial transport, cargo handling, draft safety, approach corridors.
- `marine_research`: Scientific surveys, hydrographic sampling, sensor buoys.
- `fishing`: Artisanal and commercial fisheries, INCOIS PFZ line integration, SST gradients.

### 12.3 Cloud Environment Configurations

#### Backend (`orca-backend`):
```ini
NODE_ENV=production
PORT=4000
INTERNAL_PORT=4000
MONGO_URI=mongodb://arpit7125ak_db_user:<PASSWORD>@ac-f4edo3b-shard-00-00.cynarof.mongodb.net:27017,ac-f4edo3b-shard-00-01.cynarof.mongodb.net:27017,ac-f4edo3b-shard-00-02.cynarof.mongodb.net:27017/?ssl=true&replicaSet=atlas-adxi0o-shard-0&authSource=admin&appName=Cluster0
AI_SERVICE_URL=https://orca-ai-service-b0fx.onrender.com
ALLOWED_ORIGINS=*
```

#### AI Multi-Agent Service (`orca-ai-service`):
```ini
PYTHON_VERSION=3.11.9
ENV=production
AI_SERVICE_PORT=8000
BACKEND_INTERNAL_URL=https://orca-backend-anp5.onrender.com
MONGO_URI=mongodb://arpit7125ak_db_user:<PASSWORD>@ac-f4edo3b-shard-00-00.cynarof.mongodb.net:27017,ac-f4edo3b-shard-00-01.cynarof.mongodb.net:27017,ac-f4edo3b-shard-00-02.cynarof.mongodb.net:27017/?ssl=true&replicaSet=atlas-adxi0o-shard-0&authSource=admin&appName=Cluster0
MONGO_DB=orca
ADAPTER_MODE=real
USE_MOCK_LLM=false
GEMINI_API_KEY=<YOUR_GEMINI_KEY>
OPEN_METEO_WEATHER_URL=https://api.open-meteo.com/v1/forecast
OPEN_METEO_MARINE_URL=https://marine-api.open-meteo.com/v1/marine
SACHET_ALERTS_URL=https://sachet.ndma.gov.in/cap_public_website/FetchAllAlertDetails
GEBCO_BATHYMETRY_URL=https://api.opentopodata.org/v1/gebco2020
```

#### Frontend (`orca-frontend`):
```ini
VITE_API_BASE_URL=https://orca-backend-anp5.onrender.com/api/v1
```

---

*End of Documentation — ORCA SIH26176 Reference Architecture*
